# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM spotify_catalog.gold.dimuser

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC drop table spotify_catalog.gold.dimdate

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM spotify_catalog.gold.dimtrack WHERE track_id IN (46,5) order By track_id;