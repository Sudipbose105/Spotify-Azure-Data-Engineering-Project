# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC AUTOLOADER

# COMMAND ----------

df_user=spark.readStream.format("cloudFiles")\
        .option("cloudFiles.format","parquet")\
        .option("cloudFiles.schemaLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimUser/checkpoint")\
        .option("schemaEvolutionMode","rescue")\
        .load("abfss://bronze@sbspotifyproject.dfs.core.windows.net/DimUser/")

# COMMAND ----------

display(df_user)

# COMMAND ----------

df_user1=df_user.withColumn("user_name",upper(col("user_name")))
display(df_user1)

# COMMAND ----------

import os
import sys
project_path=os.path.join(os.getcwd(),'..','..')
sys.path.append(project_path)

# COMMAND ----------

from utils.transformations import reusable

df_user_object=reusable()

df_user1=df_user_object.dropColumns(df_user1,['_rescued_data'])
display(df_user1)

# COMMAND ----------

df_user1=df_user1.dropDuplicates(['user_id'])

# COMMAND ----------

df_user1.writeStream.format("delta")\
        .option("mode","append")\
        .option("checkpointLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimUser/checkpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimUser/data")\
        .toTable("spotify_catalog.silver.DimUser")

# COMMAND ----------

# MAGIC %md
# MAGIC DimArtist

# COMMAND ----------

df_artist=spark.readStream.format("cloudFiles")\
        .option("cloudFiles.format","parquet")\
        .option("cloudFiles.schemaLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimArtist/checkpoint")\
        .option("schemaEvolutionMode","rescue")\
        .load("abfss://bronze@sbspotifyproject.dfs.core.windows.net/DimArtist/")

# COMMAND ----------

display(df_artist)

# COMMAND ----------

df_art_obj=reusable()

df_artist=df_art_obj.dropColumns(df_artist,['_rescued_data'])
df_artist=df_artist.dropDuplicates(['artist_id'])
display(df_artist)

# COMMAND ----------

df_artist.writeStream.format("delta")\
        .option("mode","append")\
        .option("checkpointLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimArtist/checkpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimArtist/data")\
        .toTable("spotify_catalog.silver.DimArtist")

# COMMAND ----------

# MAGIC %md
# MAGIC DimTrack

# COMMAND ----------

df_track=spark.readStream.format("cloudFiles")\
        .option("cloudFiles.format","parquet")\
        .option("cloudFiles.schemaLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimTrack/checkpoint")\
        .option("schemaEvolutionMode","rescue")\
        .load("abfss://bronze@sbspotifyproject.dfs.core.windows.net/DimTrack/")

# COMMAND ----------

display(df_track)

# COMMAND ----------

df_track=df_track.withColumn("durationFlag",when(col('duration_sec')<150,"Low").when(col('duration_sec')<300,"Medium").otherwise("High"))

df_track=df_track.withColumn("track_name",regexp_replace(col('track_name'),'-',' '))

df_track=reusable().dropColumns(df_track,['_rescued_data'])

display(df_track)

# COMMAND ----------

df_track.writeStream.format("delta")\
        .option("mode","append")\
        .option("checkpointLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimTrack/checkpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimTrack/data")\
        .toTable("spotify_catalog.silver.DimTrack")

# COMMAND ----------

# MAGIC %md
# MAGIC DimDate

# COMMAND ----------

df_date=spark.readStream.format("cloudFiles")\
        .option("cloudFiles.format","parquet")\
        .option("cloudFiles.schemaLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimDate/checkpoint")\
        .option("schemaEvolutionMode","rescue")\
        .load("abfss://bronze@sbspotifyproject.dfs.core.windows.net/DimDate/")

# COMMAND ----------

display(df_date)

# COMMAND ----------

df_date=reusable().dropColumns(df_date,["_rescued_data"])

# COMMAND ----------

df_date.writeStream.format("delta")\
        .option("mode","append")\
        .option("checkpointLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimDate/checkpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@sbspotifyproject.dfs.core.windows.net/DimDate/data")\
        .toTable("spotify_catalog.silver.DimDate")

# COMMAND ----------

# MAGIC %md
# MAGIC FactStream

# COMMAND ----------

df_fact=spark.readStream.format("cloudFiles")\
        .option("cloudFiles.format","parquet")\
        .option("cloudFiles.schemaLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/FactStream/checkpoint")\
        .option("schemaEvolutionMode","rescue")\
        .load("abfss://bronze@sbspotifyproject.dfs.core.windows.net/FactStream/")

# COMMAND ----------

display(df_fact)

# COMMAND ----------

df_fact=reusable().dropColumns(df_fact,["_rescued_data"])

# COMMAND ----------

df_fact.writeStream.format("delta")\
        .option("mode","append")\
        .option("checkpointLocation","abfss://silver@sbspotifyproject.dfs.core.windows.net/FactStream/checkpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@sbspotifyproject.dfs.core.windows.net/FactStream/data")\
        .toTable("spotify_catalog.silver.FactStream")